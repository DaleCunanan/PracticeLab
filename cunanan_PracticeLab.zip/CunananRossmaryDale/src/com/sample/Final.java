package com.sample;

public class Final {

	public static void main(String[] args) {
		System.out.println("These are the infos about your product: ");
		
		Product one = new Product();
		one.setName("Ipad pro");
		one.setPrice(45000);
		one.setQuantity(2);
		
		System.out.println("Product: " + one.getName());
		System.out.println("Price: " + one.getPrice());
		System.out.println("Quantity:" + one.getQuantity());
		System.out.println("Total: " + one.getQuantity()*one.getPrice());

	}

}
